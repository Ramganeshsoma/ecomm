python -m venv ecommerce_proj


cmd
ecommerce_proj\Scripts\activate
set FLASK_APP=D:\RG\src\main.py\
ecommerce_proj\Scripts\python.exe -m flask run